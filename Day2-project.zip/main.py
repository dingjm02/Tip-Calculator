


print("Welcome to the tip calculator!")
bill = float(input("what was the total bills? $"))
tip_percent = float(input("what percentage tip would you like to give? 10, 12, or 15?"))
people = int(input("how many people to split the bill?"))
final_bill = bill + (bill * tip_percent / 100)
each_person_bill = round(final_bill/people,2)
print(f"each person should pay: ${each_person_bill}")